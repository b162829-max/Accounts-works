# Driver Accounts Android app

This repository contains the Android WebView wrapper and the app layout in `app/src/main/assets/index.html`.

## Build APK with GitHub Actions
1. Create a new **empty** GitHub repository.
2. Extract this ZIP and upload the **contents** of this folder to the repository root (so `settings.gradle`, `build.gradle`, `app/`, and `.github/` are at the top level).
3. Open the **Actions** tab and run **Build Android APK** (or push a commit to `main`/`master`).
4. When the workflow succeeds, open its run and download the `Driver-Accounts-APK` artifact. Extract it to get `app-debug.apk`.

The workflow installs Gradle 8.9 and Java 17 itself; a `gradlew` wrapper file is not required. The APK is a debug APK for testing and direct installation.

## Device compatibility
The app declares Android 6.0 (API 23) as its minimum version. It is a Java/WebView app without ABI-specific native libraries, so the same APK can run on supported Android devices that have a compatible Android System WebView. Actual compatibility still depends on Android version and device configuration.
